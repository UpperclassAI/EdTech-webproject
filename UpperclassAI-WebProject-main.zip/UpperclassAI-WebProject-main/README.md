# UpperclassAI-WebProject
EdTech Platform That empowers young Africans with World-class AI education
